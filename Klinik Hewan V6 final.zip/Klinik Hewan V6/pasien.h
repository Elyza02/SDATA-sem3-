#ifndef PASIEN_H
#define PASIEN_H

#include <string>
#include <iostream>
#include <iomanip>
#include "ktp.h"

using namespace std;

/* ================== STATUS PASIEN ================== */
enum StatusPasien {
    MENUNGGU,
    DIPERIKSA,
    DIRAWAT,
    SELESAI
};

/* ================== STRUCT PASIEN ================== */
struct Pasien {
    int id;
    string ktp;          // ✅ KTP DI SINI (PENTING)
    string nama;
    string jenis;
    string layanan;
    int prioritas;
    StatusPasien status;
    string keluhan;
    string catatanDokter;

    Pasien() {
        id = 0;
        ktp = "";
        nama = "";
        jenis = "";
        layanan = "";
        prioritas = 3;
        status = MENUNGGU;
        keluhan = "";
        catatanDokter = "";
    }

    string statusToString() const {
        if (status == MENUNGGU) return "Menunggu";
        if (status == DIPERIKSA) return "Diperiksa";
        if (status == DIRAWAT)   return "Dirawat";
        if (status == SELESAI)   return "Selesai";
        return "Menunggu";
    }

    static StatusPasien stringToStatus(const string& s) {
        if (s == "Menunggu")  return MENUNGGU;
        if (s == "Diperiksa") return DIPERIKSA;
        if (s == "Dirawat")   return DIRAWAT;
        if (s == "Selesai")   return SELESAI;
        return MENUNGGU;
    }

    bool valid() const {
        if (ktp.empty()) return false;
        if (nama.empty()) return false;
        if (jenis.empty()) return false;
        if (prioritas < 1 || prioritas > 3) return false;
        return true;
    }

    void tampilLengkap() const {
        cout << "======================================\n";
        cout << "ID Pasien   : " << id << endl;
        cout << "No KTP      : " << ktp << endl;
        cout << "Nama Hewan  : " << nama << endl;
        cout << "Jenis Hewan : " << jenis << endl;
        cout << "Layanan     : " << layanan << endl;
        cout << "Prioritas   : " << prioritas << endl;
        cout << "Status      : " << statusToString() << endl;
        cout << "Keluhan     : " << keluhan << endl;
        cout << "======================================\n";
    }

    void tampilRingkas() const {
        cout << left
             << setw(5)  << id
             << setw(16) << ktp
             << setw(12) << nama
             << setw(12) << jenis
             << setw(10) << statusToString()
             << endl;
    }
};

/* ================== CIRCULAR LINKED LIST ================== */
struct NodePasien {
    Pasien data;
    NodePasien* next;
};

extern NodePasien* headPasien;

/* ===== TAMBAH PASIEN KE CLL ===== */
void tambahPasienCLL(const Pasien& p);

/* ===== LOGIN CUSTOMER BERBASIS KTP ===== */
NodePasien* loginCustomerByKTP(const string& ktp);

#endif
