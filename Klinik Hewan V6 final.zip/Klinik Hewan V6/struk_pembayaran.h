#ifndef STRUK_PEMBAYARAN_H
#define STRUK_PEMBAYARAN_H

#include <fstream>
#include <iostream>
#include "pasien.h"
#include "data_manager.h"

using namespace std;

class StrukPembayaran {
private:
    static void cetakGaris(ofstream& file) {
        file << "==============================================\n";
    }

public:
    // =================================================
    // SIMPAN STRUK DARI OBJEK PASIEN (FUNGSI LAMA)
    // =================================================
    static void simpan(const Pasien& p,
                       int biayaDasar,
                       int biayaTambahan) {
        ofstream file("struk_pembayaran.txt", ios::app);

        int total = biayaDasar + biayaTambahan;

        cetakGaris(file);
        file << "            STRUK PEMBAYARAN\n";
        file << "        KLINIK HEWAN CERIA PETS\n";
        cetakGaris(file);

        file << "ID Pasien      : " << p.id << endl;
        file << "Nama Hewan     : " << p.nama << endl;
        file << "Jenis Hewan    : " << p.jenis << endl;
        file << "----------------------------------------------\n";
        file << "Layanan        : " << p.layanan << endl;
        file << "Keluhan        : " << p.keluhan << endl;
        file << "----------------------------------------------\n";
        file << "Biaya Dasar    : Rp " << biayaDasar << endl;
        file << "Biaya Tambahan : Rp " << biayaTambahan << endl;
        file << "----------------------------------------------\n";
        file << "TOTAL BAYAR    : Rp " << total << endl;
        file << "Status         : LUNAS\n";
        cetakGaris(file);
        file << endl;

        file.close();
    }

    // =================================================
    // SIMPAN STRUK BERDASARKAN ID (AMAN, DATA TERBARU)
    // =================================================
    static void simpanById(int id,
                           int biayaDasar,
                           int biayaTambahan) {
        Pasien p;
        if (!DataManager::cariPasien(id, p)) {
            cout << "Pasien tidak ditemukan, struk gagal dibuat\n";
            return;
        }

        simpan(p, biayaDasar, biayaTambahan);
    }
};

#endif
