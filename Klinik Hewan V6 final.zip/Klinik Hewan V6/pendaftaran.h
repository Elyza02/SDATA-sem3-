#ifndef PENDAFTARAN_H
#define PENDAFTARAN_H

#include <iostream>
#include "data_manager.h"
#include "pasien.h"

using namespace std;

class Pendaftaran {
private:
    Pasien* data;
    int n;

    int cariIndex(int id) {
        for (int i = 0; i < n; i++) {
            if (data[i].id == id)
                return i;
        }
        return -1;
    }

    void loadData() {
        if (data != NULL) {
            delete[] data;
            data = NULL;
        }
        DataManager::load(data, n);
    }

    void saveData() {
        DataManager::save(data, n);
    }

public:
    Pendaftaran() {
        data = NULL;
        n = 0;
        loadData();
    }

    ~Pendaftaran() {
        if (data != NULL)
            delete[] data;
    }

    /* ================== CREATE ================== */
    void tambahPasien() {
        Pasien p;

        cout << "No KTP Pemilik : ";
        cin >> p.ktp;                     // ? KTP MASUK KE PASIEN

        p.id = DataManager::generateId();

        cout << "Nama Hewan    : ";
        cin >> p.nama;
        cout << "Jenis Hewan   : ";
        cin >> p.jenis;
        cout << "Keluhan       : ";
        cin >> p.keluhan;
        cout << "Prioritas(1-3): ";
        cin >> p.prioritas;

        p.status = MENUNGGU;
        p.layanan = "Pendaftaran";

        if (!p.valid()) {
            cout << "Data tidak valid\n";
            return;
        }

        // ===== SIMPAN KE FILE =====
        Pasien* baru = new Pasien[n + 1];
        for (int i = 0; i < n; i++)
            baru[i] = data[i];

        baru[n] = p;

        delete[] data;
        data = baru;
        n++;

        saveData();

        // ===== SIMPAN KE CIRCULAR LINKED LIST =====
        tambahPasienCLL(p);               // ? PARAMETER SUDAH BENAR

        cout << "Pasien berhasil didaftarkan dan KTP tersimpan\n";
    }

    /* ================== READ ================== */
    void tampilSemua() {
        if (n == 0 || data == NULL) {
            cout << "Data kosong\n";
            return;
        }

        for (int i = 0; i < n; i++) {
            data[i].tampilLengkap();
            cout << endl;
        }
    }

    void cariPasien() {
        int id;
        cout << "ID Pasien: ";
        cin >> id;

        int idx = cariIndex(id);
        if (idx == -1) {
            cout << "Pasien tidak ditemukan\n";
            return;
        }

        data[idx].tampilLengkap();
    }

    /* ================== UPDATE ================== */
    void ubahPasien() {
        int id;
        cout << "ID Pasien: ";
        cin >> id;

        int idx = cariIndex(id);
        if (idx == -1) {
            cout << "Pasien tidak ditemukan\n";
            return;
        }

        cout << "Nama Baru    : ";
        cin >> data[idx].nama;
        cout << "Jenis Baru   : ";
        cin >> data[idx].jenis;
        cout << "Keluhan Baru : ";
        cin >> data[idx].keluhan;
        cout << "Prioritas    : ";
        cin >> data[idx].prioritas;

        saveData();
        cout << "Data berhasil diubah\n";
    }

    /* ================== DELETE ================== */
    void hapusPasien() {
        int id;
        cout << "ID Pasien: ";
        cin >> id;

        int idx = cariIndex(id);
        if (idx == -1) {
            cout << "Pasien tidak ditemukan\n";
            return;
        }

        Pasien* baru = new Pasien[n - 1];
        int k = 0;

        for (int i = 0; i < n; i++) {
            if (i != idx)
                baru[k++] = data[i];
        }

        delete[] data;
        data = baru;
        n--;

        saveData();
        cout << "Pasien berhasil dihapus\n";
    }

    /* ================== INFO ================== */
    void jumlahPasien() {
        cout << "Jumlah pasien terdaftar: " << n << endl;
    }

    /* ================== MENU ================== */
    void menu() {
        int pilih;
        do {
            cout << "\n=== MENU PENDAFTARAN ===\n";
            cout << "1. Tambah Pasien (Pakai KTP)\n";
            cout << "2. Tampil Semua\n";
            cout << "3. Cari Pasien\n";
            cout << "4. Ubah Pasien\n";
            cout << "5. Hapus Pasien\n";
            cout << "6. Jumlah Pasien\n";
            cout << "0. Kembali\n";
            cout << "Pilih: ";
            cin >> pilih;

            switch (pilih) {
                case 1: tambahPasien(); break;
                case 2: tampilSemua(); break;
                case 3: cariPasien(); break;
                case 4: ubahPasien(); break;
                case 5: hapusPasien(); break;
                case 6: jumlahPasien(); break;
            }
        } while (pilih != 0);
    }
};

#endif
