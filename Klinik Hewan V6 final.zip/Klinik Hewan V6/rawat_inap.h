#ifndef RAWAT_INAP_H
#define RAWAT_INAP_H

#include <iostream>
#include <iomanip>
#include "struk_pembayaran.h"
#include "pasien.h"
#include "data_manager.h"

using namespace std;

struct NodeInap {
    Pasien data;
    NodeInap* next;

    NodeInap() {
        next = NULL;
    }

    NodeInap(const Pasien& p) {
        data = p;
        next = NULL;
    }
};

class RawatInap {
private:
    NodeInap* top;

    bool kosong() const {
        return top == NULL;
    }

    // ================= CLEAR STACK =================
    void clear() {
        NodeInap* cur = top;
        while (cur != NULL) {
            NodeInap* temp = cur;
            cur = cur->next;
            delete temp;
        }
        top = NULL;
    }

    int jumlahNode() const {
        int count = 0;
        NodeInap* cur = top;
        while (cur != NULL) {
            count++;
            cur = cur->next;
        }
        return count;
    }

    NodeInap* cariNode(int id) const {
        NodeInap* cur = top;
        while (cur != NULL) {
            if (cur->data.id == id)
                return cur;
            cur = cur->next;
        }
        return NULL;
    }

public:
    RawatInap() {
        top = NULL;
    }

    // ================= PUSH (MASUK RAWAT INAP) =================
    void push(const Pasien& p) {
        NodeInap* baru = new NodeInap(p);
        baru->next = top;
        top = baru;

        DataManager::ubahStatus(p.id, DIRAWAT);
        DataManager::ubahLayanan(p.id, "RawatInap");
    }

    // ================= POP (KELUAR RAWAT INAP) =================
    void pop() {
    if (kosong()) {
        cout << "Tidak ada pasien rawat inap\n";
        return;
    }

    NodeInap* hapus = top;
    int id = hapus->data.id;

    top = top->next;
    delete hapus;

    // update status pasien
    DataManager::ubahStatus(id, SELESAI);
    DataManager::ubahLayanan(id, "Selesai");

    // ===== BUAT STRUK PEMBAYARAN =====
    int biayaDasar = 50000;      // biaya pemeriksaan
    int biayaRawatInap = 100000; // biaya rawat inap

    StrukPembayaran::simpanById(
        id,
        biayaDasar,
        biayaRawatInap
    );

    cout << "Pasien keluar dari rawat inap\n";
    cout << "Struk pembayaran berhasil dibuat\n";
}


    // ================= LOAD DARI FILE =================
    void loadDariFile() {
        clear();

        Pasien* data;
        int n;
        DataManager::load(data, n);

        for (int i = 0; i < n; i++) {
            if (data[i].status == DIRAWAT) {
                NodeInap* baru = new NodeInap(data[i]);
                baru->next = top;
                top = baru;
            }
        }

        if (n > 0) delete[] data;
    }

    // ================= TAMPIL =================
    void tampil() const {
        if (kosong()) {
            cout << "Tidak ada pasien rawat inap\n";
            return;
        }

        cout << left
             << setw(5)  << "ID"
             << setw(12) << "Nama"
             << setw(12) << "Jenis"
             << setw(10) << "Status"
             << endl;
        cout << "--------------------------------------\n";

        NodeInap* cur = top;
        while (cur != NULL) {
            cout << setw(5)  << cur->data.id
                 << setw(12) << cur->data.nama
                 << setw(12) << cur->data.jenis
                 << setw(10) << cur->data.statusToString()
                 << endl;
            cur = cur->next;
        }
    }

    // ================= DETAIL PASIEN =================
    void detailPasien() const {
        int id;
        cout << "Masukkan ID: ";
        cin >> id;

        NodeInap* node = cariNode(id);
        if (node == NULL) {
            cout << "Pasien tidak ditemukan\n";
            return;
        }

        node->data.tampilLengkap();
    }

    // ================= INFO =================
    void infoJumlah() const {
        cout << "Jumlah pasien rawat inap: "
             << jumlahNode() << endl;
    }

    // ================= MENU =================
    void menu() {
        int pilih;
        do {
            cout << "\n=== MENU RAWAT INAP ===\n";
            cout << "1. Muat Data Rawat Inap\n";
            cout << "2. Tampil Pasien\n";
            cout << "3. Detail Pasien\n";
            cout << "4. Keluarkan Pasien\n";
            cout << "5. Jumlah Pasien\n";
            cout << "0. Kembali\n";
            cout << "Pilih: ";
            cin >> pilih;

            switch (pilih) {
                case 1:
                    loadDariFile();
                    cout << "Data rawat inap dimuat ulang\n";
                    break;
                case 2: tampil(); break;
                case 3: detailPasien(); break;
                case 4: pop(); break;
                case 5: infoJumlah(); break;
            }
        } while (pilih != 0);
    }
};

#endif
