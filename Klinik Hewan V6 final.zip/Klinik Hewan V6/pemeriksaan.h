#ifndef PEMERIKSAAN_H
#define PEMERIKSAAN_H

#include <iostream>
#include <fstream>
#include <iomanip>
#include "pasien.h"
#include "data_manager.h"
#include "laporan_pemeriksaan.h"

using namespace std;

struct NodePeriksa {
    Pasien data;
    NodePeriksa* next;

    NodePeriksa() {
        next = NULL;
    }

    NodePeriksa(const Pasien& p) {
        data = p;
        next = NULL;
    }
};

class Pemeriksaan {
private:
    NodePeriksa* rear;

    bool kosong() const {
        return rear == NULL;
    }

    // ================= CLEAR =================
    void clear() {
        if (kosong()) return;

        NodePeriksa* cur = rear->next;
        NodePeriksa* temp;

        while (cur != rear) {
            temp = cur;
            cur = cur->next;
            delete temp;
        }

        delete rear;
        rear = NULL;
    }

    int jumlahNode() const {
        if (kosong()) return 0;

        int count = 0;
        NodePeriksa* cur = rear->next;
        do {
            count++;
            cur = cur->next;
        } while (cur != rear->next);

        return count;
    }

    NodePeriksa* cariNode(int id) const {
        if (kosong()) return NULL;

        NodePeriksa* cur = rear->next;
        do {
            if (cur->data.id == id)
                return cur;
            cur = cur->next;
        } while (cur != rear->next);

        return NULL;
    }

public:
    Pemeriksaan() {
        rear = NULL;
    }

    // ================= ENQUEUE =================
    void enqueue(const Pasien& p) {
        NodePeriksa* baru = new NodePeriksa(p);

        if (kosong()) {
            rear = baru;
            rear->next = rear;
        } else {
            baru->next = rear->next;
            rear->next = baru;
            rear = baru;
        }
    }

    // ================= LOAD DARI FILE =================
    void loadDariFile() {
        clear();

        Pasien* data;
        int n;
        DataManager::load(data, n);

        for (int i = 0; i < n; i++) {
            if (data[i].status == DIPERIKSA) {
                enqueue(data[i]);
            }
        }

        if (n > 0) delete[] data;
    }

    // ================= TAMPIL =================
    void tampil() const {
        if (kosong()) {
            cout << "Tidak ada pasien pemeriksaan\n";
            return;
        }

        cout << left
             << setw(5)  << "ID"
             << setw(12) << "Nama"
             << setw(12) << "Jenis"
             << setw(10) << "Status"
             << endl;
        cout << "--------------------------------------\n";

        NodePeriksa* cur = rear->next;
        do {
            cout << setw(5)  << cur->data.id
                 << setw(12) << cur->data.nama
                 << setw(12) << cur->data.jenis
                 << setw(10) << cur->data.statusToString()
                 << endl;
            cur = cur->next;
        } while (cur != rear->next);
    }

    // ================= DETAIL PASIEN =================
    void detailPasien() const {
        int id;
        cout << "Masukkan ID: ";
        cin >> id;

        NodePeriksa* node = cariNode(id);
        if (node == NULL) {
            cout << "Pasien tidak ditemukan\n";
            return;
        }

        node->data.tampilLengkap();
    }

    // ================= SELESAI PERIKSA =================
        void selesaiPeriksa() {
    if (kosong()) {
        cout << "Tidak ada pasien\n";
        return;
    }

    NodePeriksa* front = rear->next;
    Pasien p = front->data;

    string hasil, tindakan;
    int pilihan;

    cout << "Hasil Pemeriksaan : ";
    cin >> hasil;
    cout << "Tindakan Medis    : ";
    cin >> tindakan;

    cout << "\nKeputusan Pasien:\n";
    cout << "1. Selesai (Pulang)\n";
    cout << "2. Rawat Inap\n";
    cout << "Pilih: ";
    cin >> pilihan;

    // simpan laporan pemeriksaan
    LaporanPemeriksaan::simpan(p, hasil, tindakan);

    if (front == rear) {
        delete front;
        rear = NULL;
    } else {
        rear->next = front->next;
        delete front;
    }

    if (pilihan == 2) {
        DataManager::ubahStatus(p.id, DIRAWAT);
        DataManager::ubahLayanan(p.id, "RawatInap");
        cout << "Pasien masuk rawat inap\n";
    } else {
        DataManager::ubahStatus(p.id, SELESAI);
        DataManager::ubahLayanan(p.id, "Selesai");
        cout << "Pasien selesai & pulang\n";
    }

        cout << "Pemeriksaan selesai & laporan tersimpan\n";
    }

    // ================= INFO =================
    void infoJumlah() const {
        cout << "Jumlah pasien diperiksa: "
             << jumlahNode() << endl;
    }

    // ================= MENU =================
    void menu() {
        int pilih;
        do {
            cout << "\n=== MENU PEMERIKSAAN ===\n";
            cout << "1. Muat Data Pemeriksaan\n";
            cout << "2. Tampil Pasien\n";
            cout << "3. Detail Pasien\n";
            cout << "4. Selesaikan Pemeriksaan\n";
            cout << "5. Jumlah Pasien\n";
            cout << "0. Kembali\n";
            cout << "Pilih: ";
            cin >> pilih;

            switch (pilih) {
                case 1:
                    loadDariFile();
                    cout << "Data pemeriksaan dimuat ulang\n";
                    break;
                case 2: tampil(); break;
                case 3: detailPasien(); break;
                case 4: selesaiPeriksa(); break;
                case 5: infoJumlah(); break;
            }
        } while (pilih != 0);
    }
};

#endif
